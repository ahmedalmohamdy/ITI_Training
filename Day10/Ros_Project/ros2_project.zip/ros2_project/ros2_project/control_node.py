#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.srv import Trigger
from turtlesim.srv import Kill
from std_srvs.srv import Empty
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math
from math import sqrt, atan2

class controll_tur(Node):
     def __init__(self):
        super().__init__("Turtle_2")
        self.client_createTurtle = self.create_client(Trigger, "Turtle_service")
        self.client_killer = self.create_client(Kill, "kill")
        self.client_clear = self.create_client(Empty, "clear")
        self.create_subscription(Pose, "Ahmed_Almohamdy/pose", self.newPose, 10)
        self.create_subscription(Pose, "turtle1/pose", self.goToGoal, 10)
        self.pub_tur1Vel = self.create_publisher(Twist, "turtle1/cmd_vel", 10)
        self.create_timer(1/30, self.timer_call)
     

        self.desierd_x=0	            
        self.desired_y=0	            
        self.tolerence = 0.5
        self.flag_reached=False 
        self.flag_isAlive=False
        self.lin = 0
        self.ang = 0


     def service_Create(self):
        while self.client_createTurtle.wait_for_service(0.25)==False:
            print("Waiting service")

        request = Trigger.Request()
        future_obj = self.client_createTurtle.call_async(request)
        future_obj.add_done_callback(self.callback_Turtle)

     def callback_Turtle(self, future_done):

        print(f"Target: Ahmed _Almohamdy located,")
        res = future_done.result()
        if res.success == True:
            self.flag_isAlive = True

     def service_killer(self):
        while self.client_killer.wait_for_service(0.25)==False:
            print("Waiting service")

        req = Kill.Request()
        req.name = "Ahmed_Almohamdy"

        fut_obj = self.client_killer.call_async(req)
        fut_obj.add_done_callback(self.callback_killer)


     def callback_killer(self, future_done):
        
        print(f"Ahmed_Almohamdy Was Killed")
        self.flag_isAlive = False

     def service_clear(self):
        while self.client_clear.wait_for_service(0.25)==False:
            print("Waiting service")

        req = Empty.Request()
        fut_obj = self.client_clear.call_async(req)

     def newPose(self, msg):
        self.desierd_x = msg.x
        self.desired_y = msg.y
        
     def goToGoal(self, msg):

        self.now_x=msg.x
        self.now_y=msg.y
        self.now_theta=msg.theta
        self.errorlin=sqrt(((self.desierd_x-self.now_x)**2)+((self.desired_y-self.now_y)**2))
        self.desired_theta=atan2((self.desired_y-self.now_y),(self.desierd_x-self.now_x))
        self.errorang=self.desired_theta-self.now_theta

        if self.errorang > math.pi:
            self.errorang -= 2*math.pi
            
        elif self.errorang < -math.pi:
            self.errorang += 2*math.pi
        self.kplin=self.errorlin*1.2
        self.lin=self.kplin   
        self.kpang=self.errorang*10
        self.ang=self.kpang 
        if (abs(self.errorlin)) < self.tolerence:
            self.lin=0
            self.ang=0
            if self.flag_reached==False:
                self.flag_reached=True

     def timer_call(self):
            msg = Twist()
            msg.linear.x=float(self.lin)
            msg.angular.z=float(self.ang)
            if self.flag_isAlive == False:
               self.service_Create()
               self.flag_reached = False
            elif (self.flag_isAlive == True) and (self.flag_reached == False):
               self.pub_tur1Vel.publish(msg)
            elif (self.flag_isAlive == True) and (self.flag_reached == True) :
               self.service_killer()
               self.service_clear()

    
     

def main(args=None):
    rclpy.init()
    x = controll_tur()
    rclpy.spin(x)
    rclpy.shutdown()

main()
