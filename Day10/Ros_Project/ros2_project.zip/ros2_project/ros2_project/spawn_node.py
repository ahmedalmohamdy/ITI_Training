#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.srv import Trigger
from turtlesim.srv import Spawn
import random

class create_turtle(Node):
     def __init__(self):
        super().__init__("Turtle_1")
        self.create_service(Trigger, "Turtle_service", self.serviceCall)
        self.client_turSpawn = self.create_client(Spawn, "spawn")

     def serviceCall(self, req, resp):
        self.service_spawn_client()
        resp.success = True
        resp.message = "Ahmed_Almohamdy"
        return resp
     
     def service_spawn_client(self):
        while self.client_turSpawn.wait_for_service(0.25)==False:
            print("Waiting for service")


        request = Spawn.Request()
        request.x = round(random.uniform(1.0,10.0), 3)
        request.y = round(random.uniform(1.0,10.0), 3)
        request.name = "Ahmed_Almohamdy"
        fut_obj = self.client_turSpawn.call_async(request)
        fut_obj.add_done_callback(self.callback)

     def callback (self,res):
          resp = Spawn.Response()
          print("Ahmed_Almohamdy Spawned Successfully")



        
def main(args=None):
    rclpy.init(args=args)
    x = create_turtle()
    rclpy.spin(x)
    rclpy.shutdown()


main()

    
        
